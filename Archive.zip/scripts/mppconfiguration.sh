#!/bin/bash


echo "parameters are as below:" >> /var/lib/waagent/command1log
echo "$@" >> /var/lib/waagent/command1log
echo "================ script starts ================================" >> /var/lib/waagent/command1log
cat $0 >> /var/lib/waagent/command1log

storageKey=${1}
tdcTimeZone=${2}
vmCount=${3}
number_of_nics=${4}
startAddresses=${5}
clusterName=${6}
dbsPassword=${7}
skuTypeValue=${8}
datadiskSize=${9}
kanjiSupport=${10}
ntpServerlist=${11}
imgencdSku=${12}
imageOffer=${13}
addressSpaces=${14}
securityFeature=${15}
timCachePercent=${16}
eid=${17}
packageSelector=${18}
term=${19}
ems_Url=${20}
storageAccountDiagnostics=${21}
byol=${22}
foldUnfold=${23}
unfoldNo=${24}
temporalValue=${25}
vp=${26}
mainframeConnectivity=${27}						   
logStorageAccount=${28}
logStorageAccountName=${29}
logStorageAccountkey=${30}
vmBaseCountDatabase=${31}

if [[ $temporalValue == "no" ]]
then
    temporal=""
elif [[ $temporalValue == "yes" ]]
then
    temporal="--enable_temporal"
else
    exit 1
fi
if [[ $datadiskSize == "0TB" ]]							  
then
    storageType="--local_storage"
else
    storageType=""
fi
if [ $logStorageAccount == "Yes" ]
then
    custom_storage=" -c --custom_log_storage_account_name $logStorageAccountName --custom_log_storage_account_key $logStorageAccountkey"
    /usr/local/bin/tdc-feed-custom-storage-info $custom_storage
else
    custom_storage=""
fi								  
source /etc/profile

/usr/local/bin/tdc-timezone $tdcTimeZone
sudo /usr/local/bin/tdc-network-configure --nodes $vmCount --num_nics $number_of_nics --systemname $clusterName --unfoldposition $unfoldNo --subnets_start_address $startAddresses --cidrs $addressSpaces


if [ $vp == "yes" ]
then
    /usr/local/bin/tdc-ecosystem-ssh --enable
fi
tdc-ntp --servers $ntpServerlist
if [ $? -ne "0" ]; then
    exit 1
fi
sleep 120s
if [[ $(blmd -p) = 33 && $byol == 'yes' ]]
then
    /usr/pde/bin/psh touch /etc/opt/teradata/tdconfig/forcebyol
    /usr/local/bin/tdc-telm -e $eid -t $packageSelector -m activate -l $ems_Url -y $term --azure_storage_account_name $storageAccountDiagnostics --azure_secret_access_key "$storageKey"
    if [ $? -ne "0" ]; then
        exit 1
    fi
fi
/usr/local/bin/tdc-init $storageType --system_name $clusterName --base_node_count $vmBaseCountDatabase --dbc_password $dbsPassword -g -p -t --sku $skuTypeValue --kanji_support $kanjiSupport --imagesku $imgencdSku --imageoffer $imageOffer --features $securityFeature --tim_db_cache $timCachePercent --fold_ready $foldUnfold --azure_log_storage_account_name $storageAccountDiagnostics --azure_log_storage_account_key "$storageKey"  $temporal --tdp_count $mainframeConnectivity

if [[ $? -ne "0" && $byol == 'yes'  ]]; then
    /usr/local/bin/tdc-telm -m revoke --use-metadata --azure_storage_account_name $storageAccountDiagnostics --azure_secret_access_key "$storageKey"
    exit 1
fi

if [ $(blmd -p) = 33 ]
then
    psh tdc-info --disk_size $datadiskSize
fi

if [ $vp == 'yes' ]
then
    /usr/local/bin/tdc-ecosystem-ssh --enable
fi
/usr/local/bin/tdc-ntp --servers $ntpServerlist
echo "net.ipv4.tcp_keepalive_time = 120" >> /etc/sysctl.conf
echo "net.ipv4.tcp_keepalive_probes = 9" >> /etc/sysctl.conf
echo "net.ipv4.tcp_keepalive_intvl = 30" >> /etc/sysctl.conf
/sbin/sysctl -p
/sbin/sysctl -a

#sudo mv /usr/local/bin/tdc-timezone /usr/local/bin/tdc-timezone-norun
sudo mv /usr/local/bin/tdc-network-configure /usr/local/bin/tdc-network-configure-norun