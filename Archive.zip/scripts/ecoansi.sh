#!/bin/bash
source /etc/profile  
playbookparam=$3
file="/etc/opt/teradata/viewpoint/vp-aws-admin-passwd-updated"
#sudo tdc-timezone $1
sudo /usr/local/bin/tdc-ecosystem-ssh --enable
cd /var/opt/teradata/tdc-orchestration
/usr/bin/env python azure_generate_req.py $2
rm -f /etc/opt/teradata/viewpoint/vp-azure-admin-passwd-updated
rm -f /etc/opt/teradata/viewpoint/vp-aws-admin-passwd-updated
				
/opt/teradata/viewpoint/bin/vp-password-update $4
sleep 60s
cd /var/opt/teradata/tdc-orchestration && ansible-playbook -i hosts site.yml -e "$playbookparam" && mv hosts hosts-norun