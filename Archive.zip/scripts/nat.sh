#!/bin/bash
source /etc/profile  
sudo sysctl -w net.ipv4.ip_forward=1
iptables -t nat -A PREROUTING -d $2 -i eth0 -j NETMAP --to $1
iptables -t nat -A POSTROUTING -j MASQUERADE
