#!/bin/bash
source /etc/profile  
#sudo tdc-timezone $1
sudo /usr/local/bin/tdc-ecosystem-ssh --enable
